---
layout: post
title:  "eventMoa 프로젝트-day01"
date: 2021-03-22 13:10:00 +0900
comments: true # 코멘트 허용
categories: project
---



# Build Log

### !!! JDK ver 1.8.0_281 

### !!! Tomcat 8.5 

### 

`cos.jar` - 파일 업로드 라이브러리

`mybatis-3.5.6` - mybatis 라이브러리

`postgresql-42.2.19.jar`  - jdk 8 버전 이상부터 4.2 driver 사용(jdbc)



**이메일 발송 라이브러리**

`activation.jar` `mail.jar `



**jstl 라이브러리**

`jstl.jar` `standard.jar`





PUBLIC `-//mybatis.org//DTD Config 3.0//EN`

 `http://mybatis.org/dtd/mybatis-3-config.dtd`

//config.xml 파일 DTD 를 위한 코드 

`-//mybatis.org//DTD Mapper 3.0//EN`

`http://mybatis.org/dtd/mybatis-3-mapper.dtd`







